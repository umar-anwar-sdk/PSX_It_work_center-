import hashlib
import logging
import re
from difflib import SequenceMatcher
from datetime import datetime
from decimal import Decimal

import pdfplumber
from django.db import transaction
from django.utils import timezone

from .models import (
    ExtractedCompanyRecord,
    PDFDocument,
    ComparisonResult,
)

logger = logging.getLogger(__name__)


KNOWN_SECTORS = (
    "AUTOMOBILE ASSEMBLER",
    "AUTOMOBILE PARTS & ACCESSORIES",
    "CABLE & ELECTRICAL GOODS",
    "CEMENT",
    "CHEMICAL",
    "COMMERCIAL BANKS",
    "ENGINEERING",
    "EXCHANGE TRADED FUNDS",
    "FERTILIZER",
    "FOOD & PERSONAL CARE PRODUCTS",
    "GLASS & CERAMICS",
    "INSURANCE",
    "INV. BANKS / INV. COS. / SECURITIES COS.",
    "OIL & GAS EXPLORATION COMPANIES",
    "OIL & GAS MARKETING COMPANIES",
    "PHARMACEUTICALS",
    "POWER GENERATION & DISTRIBUTION",
    "PROPERTY",
    "REFINERY",
    "TECHNOLOGY & COMMUNICATION",
    "TEXTILE COMPOSITE",
    "TEXTILE SPINNING",
    "TEXTILE WEAVING",
    "TRANSPORT",
)


def clean_text(text):
    if not text:
        return ""

    text = re.sub(r"\n+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_pdf_text(pdf_path):
    if hasattr(pdf_path, "path"):
        pdf_path = pdf_path.path

    if not pdf_path:
        logger.error("No PDF path was provided to extract_pdf_text.")
        return ""

    logger.info("Starting PDF text extraction for: %s", pdf_path)
    text_parts = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page_number, page in enumerate(pdf.pages, start=1):
                extracted_text = page.extract_text() or ""
                if extracted_text:
                    text_parts.append(extracted_text)
                    logger.info("Extracted page %s from PDF", page_number)
    except Exception:
        logger.exception("PDF text extraction failed for %s", pdf_path)
        raise

    full_text = "\n".join(text_parts)
    logger.info("PDF text extraction completed. Total characters: %s", len(full_text))
    return full_text


def _number_from_text(value, *, percent=False, integer=False):
    """Return the usable number from a PDF cell that may contain stray glyphs."""
    if not value:
        return None

    # Some PDFs place a watermark character inside a decimal, e.g. ``3.a82%``.
    value = re.sub(r"(?<=\d)\.[A-Za-z]+(?=\d)", ".", value)
    pattern = r"[-+]?\d+(?:\.\d+)?%" if percent else r"[-+]?\d+(?:\.\d+)?"
    match = re.search(pattern, value)
    if not match:
        return None

    if integer:
        digits = re.sub(r"\D", "", value)
        return int(digits) if digits else None

    return Decimal(match.group(0).rstrip("%"))


def _parse_pdf_table(pdf_path):
    """Read the report table by its PDF columns instead of flattened text lines.

    The Name and Sector cells are often wrapped onto separate lines.  Text-only
    extraction loses their column position and can therefore join the second
    half of a sector to the company name (or the reverse).
    """
    records = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            words = page.extract_words(use_text_flow=False, keep_blank_chars=False)
            starts = sorted(
                {
                    round(float(word["top"]), 1)
                    for word in words
                    if float(word["x0"]) < 60 and word["text"].isdigit()
                }
            )

            for index, row_top in enumerate(starts):
                next_top = starts[index + 1] if index + 1 < len(starts) else float("inf")
                row_words = [
                    word for word in words
                    if row_top - 3 <= float(word["top"]) < next_top - 1
                ]

                def cell(left, right, row_words=row_words):
                    selected = [
                        word for word in row_words
                        if left <= float(word["x0"]) < right
                        # A vertical page watermark is extracted as isolated
                        # lower-case characters over the table columns.
                        and (len(word["text"]) > 1 or word["text"] == "&")
                    ]
                    selected.sort(key=lambda word: (float(word["top"]), float(word["x0"])))
                    return " ".join(word["text"] for word in selected)

                symbol = cell(60, 108).strip()
                # In some report pages the sector column starts slightly left
                # of its header; 200 keeps values such as GLASS and POWER out
                # of the company column.
                company_name = cell(108, 200).strip()
                sector = cell(200, 315).strip()
                price = _number_from_text(cell(315, 355))
                change_value = _number_from_text(cell(355, 415))
                change_percent = _number_from_text(cell(415, 475), percent=True)
                volume = _number_from_text(cell(475, 523), integer=True)

                sector = _normalise_sector(sector)
                if not sector:
                    company_name, sector = _recover_sector_from_company(company_name)

                # A report can legitimately have a symbol and market values
                # while its company or sector is unavailable. Keep that row;
                # only standardise the OCR variations of "Unknown".
                if _is_unknown_placeholder(company_name):
                    company_name = "Unknown"
                if _is_unknown_placeholder(sector):
                    sector = "Unknown"

                # Ignore headings and rows whose numeric cells were not read.
                if (
                    not re.fullmatch(r"[A-Z][A-Z0-9.-]{1,14}", symbol)
                    or not company_name
                    or None in (price, change_value, change_percent, volume)
                ):
                    continue

                records.append(
                    {
                        "company_name": company_name,
                        "symbol": symbol,
                        "sector": sector,
                        "price": price,
                        "change_value": change_value,
                        "change_percent": change_percent,
                        "volume": volume,
                    }
                )

    return records


def _sector_key(value):
    return re.sub(r"[^A-Z0-9]", "", value.upper())


def _normalise_sector(value):
    """Correct harmless PDF glyph noise while keeping the official sector name."""
    value = clean_text(value)
    if not value:
        return ""

    value_key = _sector_key(value)
    best_sector, score = max(
        ((sector, SequenceMatcher(None, value_key, _sector_key(sector)).ratio()) for sector in KNOWN_SECTORS),
        key=lambda item: item[1],
    )
    return best_sector if score >= 0.78 else value


def _recover_sector_from_company(company_name):
    """Handle a sector printed a few pixels inside the Name column."""
    for sector in KNOWN_SECTORS:
        match = re.search(r"(?<![A-Z])" + re.escape(sector) + r"\b", company_name)
        if match:
            before_sector = re.sub(r"\b[a-z]\s*$", "", company_name[:match.start()])
            repaired_company = clean_text(before_sector + " " + company_name[match.end():])
            return repaired_company, sector
    return company_name, ""


def _is_unknown_placeholder(company_name):
    """Discard PDF placeholders, including minor OCR misspellings of Unknown."""
    tokens = re.findall(r"[A-Za-z]+", company_name.lower())
    return bool(tokens) and any(
        SequenceMatcher(None, token, "unknown").ratio() >= 0.75
        for token in tokens
    )


def extract_report_datetime(pdf_path):
    text = extract_pdf_text(pdf_path)
    report_date = None
    report_time = None

    date_match = re.search(r"(\d{2}-[A-Za-z]{3}-\d{4}|\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2})", text)
    time_match = re.search(r"(\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?)", text, re.I)

    if date_match:
        for date_format in ["%d-%b-%Y", "%d/%m/%Y", "%Y-%m-%d"]:
            try:
                report_date = datetime.strptime(date_match.group(1), date_format).date()  # noqa: DTZ007
                break
            except ValueError:
                continue

    if time_match:
        for time_format in ["%H:%M:%S", "%H:%M", "%I:%M %p"]:
            try:
                report_time = datetime.strptime(time_match.group(1), time_format).time()  # noqa: DTZ007
                break
            except ValueError:
                continue

    return report_date, report_time


def _looks_like_sector_token(token):
    if not token or token in {"-", "--"}:
        return False

    if token.isupper() and len(token) <= 20:
        return True

    if any(char in token for char in "/&."):
        return True

    if re.fullmatch(r"[A-Z0-9]+", token):
        return True

    return False


def _split_company_and_sector(prefix_tokens):
    if not prefix_tokens:
        return "", ""

    cleaned_tokens = [token for token in prefix_tokens if token not in {"-", "--"}]
    if not cleaned_tokens:
        return "", ""

    if len(cleaned_tokens) == 1:
        return cleaned_tokens[0], ""

    for size in range(len(cleaned_tokens), 0, -1):
        candidate_tokens = cleaned_tokens[-size:]
        if not candidate_tokens:
            continue

        if size >= 2 and all(_looks_like_sector_token(token) for token in candidate_tokens):
            company_tokens = cleaned_tokens[:-size]
            return " ".join(company_tokens).strip(), " ".join(candidate_tokens).strip()

        if size == 1 and _looks_like_sector_token(candidate_tokens[0]):
            company_tokens = cleaned_tokens[:-1]
            return " ".join(company_tokens).strip(), candidate_tokens[0].strip()

    return " ".join(cleaned_tokens).strip(), ""


def parse_pdf_text(text):
    records = []
    lines = [clean_text(line) for line in text.splitlines() if clean_text(line)]

    for line in lines:
        if not re.search(r"\d", line):
            continue

        if line.lower().startswith(("psx", "daily", "weekly", "sr#", "symbol", "name", "sector")):
            continue

        if "page" in line.lower() and "http" in line.lower():
            continue

        parts = line.split()
        if not parts:
            continue

        if parts[0].isdigit():
            parts = parts[1:]

        if len(parts) < 6:
            continue

        symbol = parts[0]
        if len(parts) < 6:
            continue

        price_text = parts[-5]
        change_text = parts[-4]
        change_percent_text = parts[-3]
        volume_text = parts[-2]
        prefix_tokens = parts[1:-5]
        company_name, sector = _split_company_and_sector(prefix_tokens)

        company_name = company_name if company_name != "Unknown" else ""
        if not company_name:
            continue

        cleaned_percent = change_percent_text.replace("%", "")
        cleaned_volume = volume_text.replace(",", "")
        cleaned_change = re.sub(r"[^0-9.-]", "", change_text)

        try:
            records.append(
                {
                    "company_name": company_name,
                    "symbol": symbol,
                    "sector": sector,
                    "price": Decimal(price_text),
                    "change_value": Decimal(cleaned_change),
                    "change_percent": Decimal(cleaned_percent),
                    "volume": int(cleaned_volume),
                }
            )
        except (ArithmeticError, ValueError):
            continue

    logger.info("Parsed %s company rows from PDF text", len(records))
    return records


def extract_company_information(pdf_path):
    if hasattr(pdf_path, "path"):
        pdf_path = pdf_path.path

    records = _parse_pdf_table(pdf_path)
    if records:
        logger.info("Parsed %s company rows using PDF column positions", len(records))
        return records

    # Keep a text-only fallback for reports that do not expose word positions.
    text = extract_pdf_text(pdf_path)
    return parse_pdf_text(text)


def get_file_hash(file):
    hasher = hashlib.sha256()
    was_closed = getattr(file, "closed", False)
    try:
        if hasattr(file, "seek"):
            file.seek(0)
        if hasattr(file, "chunks"):
            for chunk in file.chunks():
                hasher.update(chunk)
        else:
            hasher.update(str(file).encode("utf-8"))
        if hasattr(file, "seek"):
            file.seek(0)
    finally:
        if was_closed and hasattr(file, "close"):
            file.close()
    return hasher.hexdigest()


def save_extracted_data(pdf_document, records):
    logger.info("Saving %s extracted records for PDF %s", len(records), pdf_document.name)
    pdf_document.extracted_companies.all().delete()

    unique_records = {}
    for record in records:
        symbol = (record.get("symbol") or "").strip().upper()
        company_name = (record.get("company_name") or "").strip()
        if not symbol or not company_name:
            continue
        unique_records[symbol] = {**record, "symbol": symbol, "company_name": company_name}

    for record in unique_records.values():
        ExtractedCompanyRecord.objects.create(
            pdf_document=pdf_document,
            company_name=record.get("company_name", ""),
            symbol=record.get("symbol", ""),
            sector=record.get("sector", ""),
            price=record.get("price"),
            change_value=record.get("change_value"),
            change_percent=record.get("change_percent"),
            volume=record.get("volume"),
        )

    logger.info("Saved extracted data for PDF %s", pdf_document.name)


def process_pdf_document(pdf_document):
    logger.info("Scraping started for PDF: %s", pdf_document.name)
    file_path = pdf_document.file.path
    logger.info("PDF path: %s", file_path)

    report_date, report_time = extract_report_datetime(file_path)
    logger.info("Extracted report date/time: %s / %s", report_date, report_time)

    records = extract_company_information(file_path)
    logger.info("Parsed %s records", len(records))
    if not records:
        raise ValueError("No valid market records were found in this PDF.")
    if report_date is None:
        raise ValueError("The market report date could not be read from this PDF.")

    # Persist extraction, comparison and processed state as one unit. A failure
    # must never leave a PDF marked processed with incomplete market records.
    with transaction.atomic():
        locked_document = PDFDocument.objects.select_for_update().get(pk=pdf_document.pk)
        locked_document.report_date = report_date
        locked_document.report_time = report_time
        if not locked_document.file_hash:
            locked_document.file_hash = get_file_hash(locked_document.file)
        locked_document.processing_error = ""
        locked_document.processed_at = timezone.now()
        save_extracted_data(locked_document, records)
        compare_with_previous_pdf(locked_document)
        locked_document.is_processed = True
        locked_document.save()
        pdf_document = locked_document
    logger.info("Saved PDF metadata and extracted records for document_id=%s", pdf_document.pk)
    try:
        from pdfs.services import dispatch_market_alerts

        dispatch_market_alerts(pdf_document)
    except Exception:
        logger.exception("Market alert dispatch failed after processing PDF %s", pdf_document.pk)
    return records


def scrape_pdf(pdf_file_path):
    report_date, report_time = extract_report_datetime(pdf_file_path)
    records = extract_company_information(pdf_file_path)
    return {
        "success": True,
        "report_date": report_date,
        "report_time": report_time,
        "records": records,
        "error": None,
    }


def get_table_data(records):
    rows = []
    for item in records:
        if hasattr(item, "company_name"):
            record = item
            payload = {
                "company_name": record.company_name,
                "sector": getattr(record, "sector", ""),
                "symbol": record.symbol,
                "price": record.price,
                "change_value": record.change_value,
                "change_percent": record.change_percent,
                "volume": record.volume,
            }
        else:
            payload = item

        rows.append(
            {
                "company_name": payload.get("company_name", ""),
                "sector": payload.get("sector", ""),
                "symbol": payload.get("symbol", ""),
                "price": format_decimal(payload.get("price")),
                "change_value": format_decimal(payload.get("change_value")),
                "change_percent": format_decimal(payload.get("change_percent")),
                "volume": payload.get("volume", ""),
            }
        )
    return rows


def format_decimal(value):
    if value is None:
        return ""
    if isinstance(value, Decimal):
        return format(value, ".2f")
    return str(value)




def compare_with_previous_pdf(current_pdf):
    """
    Compare current PDF with the most recent previous processed PDF.
    """

    previous_pdf = (
        PDFDocument.objects.filter(
            is_processed=True,
            report_date__lt=current_pdf.report_date,
        )
        .order_by("-report_date", "-report_time")
        .first()
    )

    # First PDF hai to compare nahi hoga
    if previous_pdf is None:
        logger.info("No previous PDF found. Skipping comparison.")
        return

    previous_records = {
        item.symbol: item
        for item in previous_pdf.extracted_companies.all()
    }

    current_records = {
        item.symbol: item
        for item in current_pdf.extracted_companies.all()
    }

    # Agar dobara compare ho to purana result delete kar do
    ComparisonResult.objects.filter(current_pdf=current_pdf).delete()

    # Existing
    for symbol in previous_records.keys() & current_records.keys():

        old = previous_records[symbol]
        new = current_records[symbol]

        ComparisonResult.objects.create(
            previous_pdf=previous_pdf,
            current_pdf=current_pdf,
            symbol=symbol,
            company_name=new.company_name,
            status="EXISTING",
            previous_price=old.price,
            current_price=new.price,
        )

    # New
    for symbol in current_records.keys() - previous_records.keys():

        new = current_records[symbol]

        ComparisonResult.objects.create(
            previous_pdf=previous_pdf,
            current_pdf=current_pdf,
            symbol=symbol,
            company_name=new.company_name,
            status="NEW",
            current_price=new.price,
        )

    # Removed
    for symbol in previous_records.keys() - current_records.keys():

        old = previous_records[symbol]

        ComparisonResult.objects.create(
            previous_pdf=previous_pdf,
            current_pdf=current_pdf,
            symbol=symbol,
            company_name=old.company_name,
            status="REMOVED",
            previous_price=old.price,
        )

    logger.info("Comparison completed successfully.")
